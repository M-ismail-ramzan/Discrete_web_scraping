Instruction for Running the Code

1) Do pip install -r requirements.txt ( better if u do in virtual env)
2) Start the start.py file by using the command 

-- python start.py   --> python2.x
OR
-- python3 start.py  --> python3.x